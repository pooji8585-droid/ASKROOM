plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.askroom.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.askroom.app"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.zxing:core:3.5.3")   // QR code for the join link
    implementation("org.nanohttpd:nanohttpd-websocket:2.3.1")   // local HTTP + WebSocket server
}
