package com.askroom.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import java.net.*
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Collections
import kotlin.concurrent.thread

/** Offline discovery: mDNS (NSD) + UDP broadcast + unicast to the Wi-Fi gateway (covers hotspot). */
class Net(ctx: Context) {
    private val app = ctx.applicationContext
    private val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val lock = wifi.createMulticastLock("askroom").apply { setReferenceCounted(false); try { acquire() } catch (e: Exception) {} }
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private var resp: DatagramSocket? = null
    @Volatile private var resolving = false
    private val PORT = 41234

    private fun tag(code: String) = MessageDigest.getInstance("SHA-256").digest("askroom:$code".toByteArray())
        .take(4).joinToString("") { "%02x".format(it) }

    /** Keep using Wi-Fi even when it has no internet (Android would otherwise drop to mobile data). */
    fun bindWifi() {
        try {
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.requestNetwork(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) { cm.bindProcessToNetwork(n) }
            })
        } catch (e: Exception) {}
    }

    fun ips(): List<String> = Collections.list(NetworkInterface.getNetworkInterfaces() ?: return emptyList())
        .flatMap { Collections.list(it.inetAddresses) }
        .filter { it is Inet4Address && !it.isLoopbackAddress }.sortedByDescending { it.isSiteLocalAddress }.mapNotNull { it.hostAddress }

    // ---------- host side ----------
    fun advertise(code: String, port: Int) {
        try {
            val si = NsdServiceInfo().apply { serviceName = "askroom-" + tag(code); serviceType = "_askroom._tcp."; setPort(port) }
            reg = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            nsd.registerService(si, NsdManager.PROTOCOL_DNS_SD, reg)
        } catch (e: Exception) {}
        try {
            val t = tag(code)
            val s = DatagramSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
            resp = s
            thread(isDaemon = true) {
                while (!s.isClosed) {
                    try {
                        val p = DatagramPacket(ByteArray(128), 128); s.receive(p)
                        if (String(p.data, 0, p.length) == "ASKROOM?$t") {
                            val r = "ASKROOM!$t:$port".toByteArray()
                            s.send(DatagramPacket(r, r.size, p.address, p.port))
                        }
                    } catch (e: Exception) {}
                }
            }
        } catch (e: Exception) {}
    }

    fun stopAdvertise() {
        try { reg?.let { nsd.unregisterService(it) } } catch (e: Exception) {}
        reg = null
        try { resp?.close() } catch (e: Exception) {}
        resp = null
    }

    // ---------- participant side ----------
    private fun targets(): List<InetAddress> {
        val out = linkedSetOf<InetAddress>(InetAddress.getByName("255.255.255.255"))
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
            val lp = cm.getLinkProperties(n) ?: continue
            for (la in lp.linkAddresses) {
                val a = la.address
                if (a is Inet4Address) {
                    val ip = ByteBuffer.wrap(a.address).int
                    val mask = if (la.prefixLength == 0) 0 else (-1 shl (32 - la.prefixLength))
                    out.add(InetAddress.getByAddress(ByteBuffer.allocate(4).putInt(ip or mask.inv()).array()))
                }
            }
            for (r in lp.routes) { val g = r.gateway; if (g is Inet4Address && !g.isAnyLocalAddress) out.add(g) }
        }
        @Suppress("DEPRECATION")
        val d = wifi.dhcpInfo?.gateway ?: 0
        if (d != 0) out.add(InetAddress.getByAddress(byteArrayOf(d.toByte(), (d shr 8).toByte(), (d shr 16).toByte(), (d shr 24).toByte())))
        return out.toList()
    }

    fun discover(code: String, cb: (String, Int) -> Unit) {
        stopDiscover()
        val t = tag(code)
        val end = System.currentTimeMillis() + 12000
        try {   // mDNS
            val l = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(s: String) {}
                override fun onStartDiscoveryFailed(s: String, e: Int) {}
                override fun onStopDiscoveryFailed(s: String, e: Int) {}
                override fun onDiscoveryStopped(s: String) {}
                override fun onServiceLost(i: NsdServiceInfo) {}
                override fun onServiceFound(i: NsdServiceInfo) {
                    if (!i.serviceName.startsWith("askroom-$t") || resolving) return
                    resolving = true
                    @Suppress("DEPRECATION")
                    nsd.resolveService(i, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(s: NsdServiceInfo, e: Int) { resolving = false }
                        override fun onServiceResolved(s: NsdServiceInfo) {
                            resolving = false
                            @Suppress("DEPRECATION") val h = s.host?.hostAddress
                            if (h != null) cb(h, s.port)
                        }
                    })
                }
            }
            disc = l
            nsd.discoverServices("_askroom._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {}
        thread(isDaemon = true) {   // UDP broadcast + gateway unicast
            try {
                val s = DatagramSocket().apply { broadcast = true; soTimeout = 250 }
                val msg = "ASKROOM?$t".toByteArray()
                var next = 0L
                while (System.currentTimeMillis() < end) {
                    if (System.currentTimeMillis() >= next) {
                        next = System.currentTimeMillis() + 700
                        for (a in targets()) try { s.send(DatagramPacket(msg, msg.size, a, PORT)) } catch (e: Exception) {}
                    }
                    try {
                        val p = DatagramPacket(ByteArray(128), 128); s.receive(p)
                        val r = String(p.data, 0, p.length)
                        val h = p.address.hostAddress
                        if (h != null && r.startsWith("ASKROOM!$t:")) cb(h, r.substringAfter("$t:").toInt())
                    } catch (e: SocketTimeoutException) {}
                }
                s.close()
            } catch (e: Exception) {}
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ if (disc === null) {} else stopDiscover() }, 13000)
    }

    fun stopDiscover() { try { disc?.let { nsd.stopServiceDiscovery(it) } } catch (e: Exception) {}; disc = null; resolving = false }
    fun close() { stopAdvertise(); stopDiscover(); try { lock.release() } catch (e: Exception) {} }
}
