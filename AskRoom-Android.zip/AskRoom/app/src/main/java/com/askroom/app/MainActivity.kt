package com.askroom.app

import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var net: Net
    private var hub: Hub? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCb = null
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // the host server must stay alive
        net = Net(this); net.bindWifi()
        web = WebView(this); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { picker.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
        }
        web.addJavascriptInterface(Bridge(), "AskRoomNative")
        web.loadUrl("file:///android_asset/www/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun startHost(): String {
            stopHost()
            val code = (100000 + SecureRandom().nextInt(900000)).toString()
            val key = UUID.randomUUID().toString()
            fun make(port: Int) = Hub(this@MainActivity, code, key, port).also { it.start(0, false) }  // 0 = no read timeout
            val h = try { make(8765) } catch (e: Exception) { make(0) }
            hub = h
            net.advertise(code, h.listeningPort)
            return JSONObject().put("code", code).put("port", h.listeningPort).put("key", key)
                .put("ips", JSONArray(net.ips())).toString()
        }
        @JavascriptInterface fun qr(text: String): String = try {
            val m = com.google.zxing.qrcode.QRCodeWriter().encode(text, com.google.zxing.BarcodeFormat.QR_CODE, 0, 0)
            (0 until m.height).joinToString("\n") { y -> (0 until m.width).joinToString("") { x -> if (m.get(x, y)) "1" else "0" } }
        } catch (e: Exception) { "" }
        @JavascriptInterface fun stopHost() { try { hub?.stop() } catch (e: Exception) {}; hub = null; net.stopAdvertise() }
        @JavascriptInterface fun discover(code: String) {
            net.discover(code) { ip, port -> runOnUiThread { web.evaluateJavascript("window.__found&&window.__found('$ip',$port)", null) } }
        }
    }

    override fun onDestroy() { try { hub?.stop() } catch (e: Exception) {}; net.close(); super.onDestroy() }
}
