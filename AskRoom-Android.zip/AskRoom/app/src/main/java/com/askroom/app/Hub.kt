package com.askroom.app

import android.content.Context
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import fi.iki.elonen.NanoWSD
import fi.iki.elonen.NanoWSD.WebSocket
import fi.iki.elonen.NanoWSD.WebSocketFrame
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Local room server running on the host phone: HTTP (serves the UI) + WebSocket (live room). */
class Hub(private val ctx: Context, private val code: String, private val hostKey: String, port: Int) : NanoWSD(port) {

    inner class Peer(val id: String, val ws: Sock, val name: String, val host: Boolean) {
        @Volatile var seen = System.currentTimeMillis()
    }

    inner class Sock(s: IHTTPSession) : WebSocket(s) {
        @Volatile var me: Peer? = null
        override fun onOpen() {}
        override fun onClose(c: WebSocketFrame.CloseCode?, r: String?, remote: Boolean) { drop(this) }
        override fun onMessage(m: WebSocketFrame) { try { handle(this, JSONObject(m.textPayload)) } catch (e: Exception) {} }
        override fun onPong(p: WebSocketFrame?) {}
        override fun onException(e: IOException?) { drop(this) }
    }

    private val peers = ConcurrentHashMap<String, Peer>()
    @Volatile private var question: JSONObject? = null
    @Volatile private var alive = true

    private val reaper = Thread {
        while (alive) {
            try { Thread.sleep(5000) } catch (e: InterruptedException) {}
            val now = System.currentTimeMillis()
            peers.values.filter { now - it.seen > 30000 }.forEach { p ->      // dead phone / Wi-Fi dropped
                drop(p.ws)
                try { p.ws.close(WebSocketFrame.CloseCode.GoingAway, "timeout", false) } catch (e: Exception) {}
            }
        }
    }.apply { isDaemon = true }

    override fun start(timeout: Int, daemon: Boolean) { super.start(timeout, daemon); reaper.start() }
    override fun stop() { alive = false; reaper.interrupt(); super.stop() }

    override fun openWebSocket(s: IHTTPSession): WebSocket = Sock(s)

    // Browsers on the same network can open http://<host-ip>:<port> and get the same UI.
    override fun serveHttp(session: IHTTPSession): Response = try {
        newChunkedResponse(Status.OK, "text/html; charset=utf-8", ctx.assets.open("www/index.html"))
    } catch (e: Exception) { newFixedLengthResponse(Status.NOT_FOUND, "text/plain", "not found") }

    private fun tx(p: Peer, o: JSONObject) { try { p.ws.send(o.toString()) } catch (e: Exception) {} }
    private fun err(s: Sock, msg: String) { try { s.send(JSONObject().put("t", "err").put("msg", msg).toString()) } catch (e: Exception) {} }

    private fun roster(): JSONArray {
        val a = JSONArray()
        peers.values.sortedBy { !it.host }.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("host", it.host)) }
        return a
    }

    private fun presence(ev: String, who: Peer) {
        val o = JSONObject().put("t", "presence").put("ev", ev).put("id", who.id).put("name", who.name).put("members", roster())
        peers.values.forEach { if (it.id != who.id) tx(it, o) }
    }

    private fun drop(s: Sock) {
        val p = s.me ?: return
        if (peers.remove(p.id) != null) presence("leave", p)
    }

    private fun handle(s: Sock, j: JSONObject) {
        val me = s.me
        when (j.optString("t")) {
            "hello" -> {
                if (me != null) return
                val host = j.optString("role") == "host"
                if (host && j.optString("key") != hostKey) { err(s, "دسترسی میزبان نامعتبر است"); return }
                if (!host && j.optString("code") != code) { err(s, "کد اتاق اشتباه است"); return }
                if (host) peers.values.filter { it.host }.forEach {
                    peers.remove(it.id)
                    try { it.ws.close(WebSocketFrame.CloseCode.NormalClosure, "replaced", false) } catch (e: Exception) {}
                }
                val nm = j.optString("name").trim().take(24).ifBlank { if (host) "میزبان" else "شرکت‌کننده" }
                val p = Peer(UUID.randomUUID().toString().take(8), s, nm, host)
                s.me = p; peers[p.id] = p
                val o = JSONObject().put("t", "joined").put("id", p.id).put("members", roster())
                question?.let { o.put("q", it) }
                tx(p, o)
                presence("join", p)
            }
            "hb" -> if (me != null) { me.seen = System.currentTimeMillis(); tx(me, JSONObject().put("t", "hb")) }
            "q" -> if (me != null && me.host) {
                val q = JSONObject().put("text", j.optString("text")).put("img", j.optString("img"))
                question = q
                val o = JSONObject(q.toString()).put("t", "q")
                peers.values.filter { !it.host }.forEach { tx(it, o) }
            }
            "a" -> if (me != null && !me.host) {
                me.seen = System.currentTimeMillis()
                val o = JSONObject().put("t", "a").put("id", me.id).put("name", me.name)
                    .put("text", j.optString("text")).put("img", j.optString("img"))
                peers.values.filter { it.host }.forEach { tx(it, o) }
            }
        }
    }
}
