package com.askroom.app

import android.content.Context
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import fi.iki.elonen.NanoWSD
import fi.iki.elonen.NanoWSD.WebSocket
import fi.iki.elonen.NanoWSD.WebSocketFrame
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Local room server on the host phone: HTTP (serves the UI) + WebSocket (live room, answers, scores). */
class Hub(private val ctx: Context, private val code: String, private val hostKey: String, port: Int) : NanoWSD(port) {

    inner class Peer(val id: String, val ws: Sock, val name: String, val host: Boolean) {
        @Volatile var seen = System.currentTimeMillis()
    }

    inner class Sock(s: IHTTPSession) : WebSocket(s) {
        @Volatile var me: Peer? = null
        override fun onOpen() {}
        override fun onClose(c: WebSocketFrame.CloseCode?, r: String?, remote: Boolean) { drop(this) }
        override fun onMessage(m: WebSocketFrame) { try { handle(this, JSONObject(m.textPayload)) } catch (e: Exception) {} }
        override fun onPong(p: WebSocketFrame?) {}
        override fun onException(e: IOException?) { drop(this) }
    }

    /** A player (guest). Kept after disconnect so score survives reconnecting. */
    class P(val id: String, n: String) {
        val t = System.currentTimeMillis()
        @Volatile var name = n
        @Volatile var score = 0.0
        @Volatile var answer: JSONObject? = null
        @Volatile var grade: String? = null      // c = correct, a = almost, b = both correct, w = wrong
        @Volatile var delta = 0.0
        @Volatile var partner: String? = null
    }

    private val peers = ConcurrentHashMap<String, Peer>()
    private val players = ConcurrentHashMap<String, P>()
    @Volatile private var question: JSONObject? = null
    @Volatile private var alive = true
    @Volatile private var secs = 0          // time limit of the current question (0 = none)
    @Volatile private var endAt = 0L
    private val history = java.util.concurrent.CopyOnWriteArrayList<JSONObject>()   // sent questions (no images)
    @Volatile private var qCount = 0

    private fun historyJson(): JSONArray { val a = JSONArray(); history.forEach { a.put(it) }; return a }
    private fun pushHistory() {
        val o = JSONObject().put("t", "hist").put("list", historyJson())
        peers.values.filter { it.host }.forEach { tx(it, o) }
    }

    private fun qPayload(): JSONObject {
        val o = JSONObject(question?.toString() ?: "{}")
        o.put("secs", secs).put("left", if (endAt > 0) maxOf(0L, endAt - System.currentTimeMillis()) else 0L)
        return o
    }

    private val reaper = Thread {
        while (alive) {
            try { Thread.sleep(5000) } catch (e: InterruptedException) {}
            val now = System.currentTimeMillis()
            peers.values.filter { now - it.seen > 30000 }.forEach { p ->
                drop(p.ws)
                try { p.ws.close(WebSocketFrame.CloseCode.GoingAway, "timeout", false) } catch (e: Exception) {}
            }
        }
    }.apply { isDaemon = true }

    override fun start(timeout: Int, daemon: Boolean) {
        try { File(ctx.cacheDir, "media").deleteRecursively() } catch (e: Exception) {}
        super.start(timeout, daemon); reaper.start()
    }
    override fun stop() {
        alive = false; reaper.interrupt(); super.stop()
        try { File(ctx.cacheDir, "media").deleteRecursively() } catch (e: Exception) {}
    }

    override fun openWebSocket(s: IHTTPSession): WebSocket = Sock(s)

    // ---- light video support: raw upload to the host phone's cache (no base64, no RAM), streamed back with Range ----
    private val MAX_MEDIA = 30L * 1024 * 1024
    private val vidRe = Regex("[a-f0-9]{16}\\.[a-z0-9]{1,4}")
    private fun cleanVid(s: String) = if (vidRe.matches(s)) s else ""
    private fun mediaDir() = File(ctx.cacheDir, "media").apply { mkdirs() }

    private fun txt(st: Status, s: String): Response {
        val r = newFixedLengthResponse(st, "text/plain; charset=utf-8", s)
        r.addHeader("Access-Control-Allow-Origin", "*")
        return r
    }

    override fun serveHttp(session: IHTTPSession): Response {
        return try {
            val uri = session.uri
            when {
                session.method == Method.OPTIONS -> txt(Status.OK, "").also { it.addHeader("Access-Control-Allow-Headers", "*") }
                uri == "/upload" && session.method == Method.POST -> upload(session)
                uri.startsWith("/media/") -> media(session, uri.removePrefix("/media/"))
                else -> newChunkedResponse(Status.OK, "text/html; charset=utf-8", ctx.assets.open("www/index.html"))
            }
        } catch (e: Exception) { txt(Status.INTERNAL_ERROR, "error") }
    }

    private fun upload(s: IHTTPSession): Response {
        if (s.parameters["c"]?.firstOrNull() != code) return txt(Status.FORBIDDEN, "کد اتاق اشتباه است")
        val ext = (s.parameters["x"]?.firstOrNull() ?: "mp4").lowercase().filter { it in 'a'..'z' || it in '0'..'9' }.take(4).ifBlank { "mp4" }
        val len = s.headers["content-length"]?.toLongOrNull() ?: 0L
        if (len > MAX_MEDIA + 300000L) return txt(Status.BAD_REQUEST, "حجم فیلم بیشتر از ۳۰ مگابایت است")
        val files = HashMap<String, String>()
        s.parseBody(files)
        val tmp = files["file"] ?: return txt(Status.BAD_REQUEST, "فایلی نیامد")
        val f = File(tmp)
        if (f.length() > MAX_MEDIA) { f.delete(); return txt(Status.BAD_REQUEST, "حجم فیلم بیشتر از ۳۰ مگابایت است") }
        val name = UUID.randomUUID().toString().replace("-", "").take(16).lowercase() + "." + ext
        val dest = File(mediaDir(), name)
        if (!f.renameTo(dest)) { f.copyTo(dest, true); f.delete() }
        return txt(Status.OK, name)
    }

    private fun media(s: IHTTPSession, name: String): Response {
        if (!vidRe.matches(name)) return txt(Status.NOT_FOUND, "not found")
        val f = File(mediaDir(), name)
        if (!f.exists()) return txt(Status.NOT_FOUND, "not found")
        val total = f.length()
        val mime = when (name.substringAfter('.')) { "webm" -> "video/webm"; "3gp" -> "video/3gpp"; "mov" -> "video/quicktime"; else -> "video/mp4" }
        val rg = s.headers["range"]
        if (rg != null && rg.startsWith("bytes=")) {
            val p = rg.removePrefix("bytes=").split("-")
            val start = p.getOrNull(0)?.toLongOrNull() ?: 0L
            var end = p.getOrNull(1)?.toLongOrNull() ?: (total - 1)
            if (end >= total) end = total - 1
            if (start > end) return newFixedLengthResponse(Status.RANGE_NOT_SATISFIABLE, "text/plain", "")
            val ins = FileInputStream(f); ins.channel.position(start)
            val r = newFixedLengthResponse(Status.PARTIAL_CONTENT, mime, ins, end - start + 1)
            r.addHeader("Content-Range", "bytes $start-$end/$total"); r.addHeader("Accept-Ranges", "bytes")
            return r
        }
        val r = newFixedLengthResponse(Status.OK, mime, FileInputStream(f), total)
        r.addHeader("Accept-Ranges", "bytes")
        return r
    }

    private fun tx(p: Peer, o: JSONObject) { try { p.ws.send(o.toString()) } catch (e: Exception) {} }
    private fun err(s: Sock, msg: String) { try { s.send(JSONObject().put("t", "err").put("msg", msg).toString()) } catch (e: Exception) {} }
    private fun hosts() = peers.values.filter { it.host }

    private fun roster(): JSONArray {
        val a = JSONArray()
        peers.values.sortedBy { !it.host }.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("host", it.host)) }
        return a
    }

    private fun pJson(p: P, withAnswer: Boolean): JSONObject {
        val o = JSONObject().put("id", p.id).put("name", p.name).put("online", peers.containsKey(p.id))
            .put("score", p.score).put("grade", p.grade ?: JSONObject.NULL)
        if (withAnswer) o.put("answer", p.answer ?: JSONObject.NULL)
        return o
    }

    private fun playersJson(withAnswer: Boolean): JSONArray {
        val a = JSONArray()
        players.values.sortedBy { it.t }.forEach { a.put(pJson(it, withAnswer)) }
        return a
    }

    private fun pushScores() {
        val o = JSONObject().put("t", "scores").put("players", playersJson(false))
        hosts().forEach { tx(it, o) }
    }

    private fun presence(ev: String, who: Peer) {
        val o = JSONObject().put("t", "presence").put("ev", ev).put("id", who.id).put("name", who.name).put("members", roster())
        peers.values.forEach { if (it.id != who.id) tx(it, o) }
    }

    private fun drop(s: Sock) {
        val p = s.me ?: return
        if (peers.remove(p.id, p)) { presence("leave", p); pushScores() }
    }

    private fun notifyP(p: P) {
        peers[p.id]?.let { tx(it, JSONObject().put("t", "graded").put("g", p.grade ?: "").put("delta", p.delta).put("total", p.score)) }
    }

    /** Scoring: correct 2, almost 1, wrong 0, both-correct 0.5 each. Re-grading undoes the old points first. */
    private fun setGrade(p: P, g: String, d: Double) {
        p.score -= p.delta
        p.partner?.let { pid ->
            players[pid]?.let { q ->
                if (q.grade == "b") { q.score -= q.delta; q.delta = 0.0; q.grade = null; q.partner = null; notifyP(q) }
            }
        }
        p.partner = null
        p.grade = g; p.delta = d; p.score += d
    }

    private fun handle(s: Sock, j: JSONObject) {
        val me = s.me
        when (j.optString("t")) {
            "hello" -> {
                if (me != null) return
                val host = j.optString("role") == "host"
                val raw = j.optString("name").trim().take(24)
                if (host && j.optString("key") != hostKey) { err(s, "دسترسی میزبان نامعتبر است"); return }
                if (!host && j.optString("code") != code) { err(s, "کد اتاق اشتباه است"); return }
                if (!host && raw.isBlank()) { err(s, "نام لازم است"); return }
                val id = if (host) "host" else
                    j.optString("pid").filter { it.isLetterOrDigit() || it == '-' }.take(40).ifBlank { UUID.randomUUID().toString() }
                peers.remove(id)?.let { old -> try { old.ws.close(WebSocketFrame.CloseCode.NormalClosure, "replaced", false) } catch (e: Exception) {} }
                val p = Peer(id, s, raw.ifBlank { "میزبان" }, host)
                s.me = p; peers[id] = p
                val o = JSONObject().put("t", "joined").put("id", id).put("members", roster())
                if (question != null) o.put("q", qPayload())
                if (host) { o.put("players", playersJson(true)); o.put("hist", historyJson()) }
                else {
                    val pl = players.getOrPut(id) { P(id, p.name) }
                    pl.name = p.name
                    o.put("me", JSONObject().put("score", pl.score).put("grade", pl.grade ?: JSONObject.NULL).put("delta", pl.delta))
                }
                tx(p, o)
                presence("join", p)
                pushScores()
            }
            "hb" -> if (me != null) { me.seen = System.currentTimeMillis(); tx(me, JSONObject().put("t", "hb")) }
            "q" -> if (me != null && me.host) {
                val cat = j.optString("cat").trim().take(30)
                val q = JSONObject().put("text", j.optString("text")).put("img", j.optString("img")).put("cat", cat).put("vid", cleanVid(j.optString("vid")))
                qCount++
                history.add(JSONObject().put("n", qCount).put("cat", cat).put("text", j.optString("text").take(300))
                    .put("img", j.optString("img").isNotEmpty()).put("vid", cleanVid(j.optString("vid")).isNotEmpty()).put("secs", j.optInt("secs", 0).coerceIn(0, 3600))
                    .put("ts", System.currentTimeMillis()))
                if (history.size > 200) history.removeAt(0)
                question = q
                secs = j.optInt("secs", 0).coerceIn(0, 3600)
                endAt = if (secs > 0) System.currentTimeMillis() + secs * 1000L else 0L
                players.values.forEach { it.answer = null; it.grade = null; it.delta = 0.0; it.partner = null }
                val o = qPayload().put("t", "q")
                peers.values.filter { !it.host }.forEach { tx(it, o) }
                pushHistory()
                pushScores()
            }
            "a" -> if (me != null && !me.host) {
                me.seen = System.currentTimeMillis()
                val pl = players[me.id] ?: return
                if (pl.grade != null) { tx(me, JSONObject().put("t", "info").put("msg", "این سؤال قبلاً امتیاز گرفته است")); return }
                pl.answer = JSONObject().put("text", j.optString("text")).put("img", j.optString("img")).put("vid", cleanVid(j.optString("vid")))
                val o = JSONObject().put("t", "a").put("id", me.id).put("name", me.name)
                    .put("text", j.optString("text")).put("img", j.optString("img")).put("vid", cleanVid(j.optString("vid")))
                hosts().forEach { tx(it, o) }
            }
            "g" -> if (me != null && me.host) {
                val g = j.optString("g")
                val p = players[j.optString("id")] ?: return
                when (g) {
                    "c" -> { setGrade(p, "c", 2.0); notifyP(p) }
                    "a" -> { setGrade(p, "a", 1.0); notifyP(p) }
                    "w" -> { setGrade(p, "w", 0.0); notifyP(p) }
                    "b" -> {
                        val p2 = players[j.optString("pair")] ?: return
                        if (p2.id == p.id) return
                        setGrade(p, "b", 0.5); setGrade(p2, "b", 0.5)
                        p.partner = p2.id; p2.partner = p.id
                        notifyP(p); notifyP(p2)
                    }
                    else -> return
                }
                pushScores()
            }
        }
    }
}
